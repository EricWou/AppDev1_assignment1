﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppDev1_Assignment2_wpf.Models
{
    internal class Market
    {
        public string product_name { get; set; }
        public int product_id { get; set; }
        public int amount { get; set; }
        public double price { get; set; }
    }
}
