﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppDev1_Assignment2_wpf.Models
{
    internal class Response
    {
        public int status_code { get; set; }
        public string status_message { get; set; }
        public Market product { get; set; }
        public List<Market> products { get; set; }
        public ArrayList purchase {  get; set; }
    }
}
