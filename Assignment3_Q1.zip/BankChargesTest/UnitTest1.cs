using Assignment3;
using Assignment3.Models;
using System.Windows.Media.Animation;

namespace BankChargesTest
{
    public class Tests
    {
        BankCharges bank { get; set; } = null;

        [SetUp]
        public void Setup()
        {
            bank = new BankCharges(4000, 20);
        }

        [Test]
        public void calculateFeesTest()
        {
            double expected_Fees = 11.6, actual_Fees;

            actual_Fees = bank.calculateFees();


            Assert.AreEqual(expected_Fees,actual_Fees);

            Assert.That(actual_Fees, Is.TypeOf<double>());

            Assert.Pass();
        }

        [Test]
        public void calculateAccBalanceTest()
        {
            double expected_AccBalance = 3988.4, actual_AccBalance;

            actual_AccBalance = bank.calculateAccBalance();


            Assert.AreEqual(expected_AccBalance, actual_AccBalance);

            Assert.That(actual_AccBalance, Is.TypeOf<double>());

            Assert.Pass();
        }


    }
}