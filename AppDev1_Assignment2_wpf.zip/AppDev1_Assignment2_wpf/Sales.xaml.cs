﻿using AppDev1_Assignment2_wpf.Models;
using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace AppDev1_Assignment2_wpf
{
    /// <summary>
    /// Interaction logic for Sales.xaml
    /// </summary>
    public partial class Sales : Window
    {
        HttpClient httpclient = new HttpClient();

        public Sales()
        {
            httpclient.BaseAddress = new Uri("https://localhost:7025/Market/");

            httpclient.DefaultRequestHeaders.Accept.Clear();

            httpclient.DefaultRequestHeaders.Accept.Add
                (new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));

            InitializeComponent();
        }

        private async void datagrid_button_Click(object sender, RoutedEventArgs e)
        {
            var serverResponse = await httpclient.GetStringAsync("GetAllProducts");

            Response responseJSON = JsonConvert.DeserializeObject<Response>(serverResponse);

            market_datagrid.ItemsSource = responseJSON.products;
            DataContext = this;
        }

        private async void purchase_button_Click(object sender, RoutedEventArgs e)
        {
            string name = product_name_box.Text;
            int amount = int.Parse(amount_box.Text);

            ArrayList purchase = new ArrayList();
            purchase.Add(name);
            purchase.Add(amount);
            //name will be purchase[0] and amount will be purchase[1]

            var serverResponse = await httpclient.PutAsJsonAsync("PurchaseProduct/", purchase);
            //also need to update to include the total price for the customer
            //also need to update so that customer can purchase multiple items at once
            MessageBox.Show(serverResponse.ToString());
        }

        private void return_button_Click(object sender, RoutedEventArgs e)
        {
            MainWindow window1 = new MainWindow();
            window1.Show();
            this.Close();
        }
    }
}
