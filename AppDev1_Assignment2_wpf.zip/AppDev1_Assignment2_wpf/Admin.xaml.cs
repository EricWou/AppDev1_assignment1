﻿using AppDev1_Assignment2_wpf.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace AppDev1_Assignment2_wpf
{
    /// <summary>
    /// Interaction logic for Admin.xaml
    /// </summary>
    public partial class Admin : Window
    {
        HttpClient httpclient = new HttpClient();

        public Admin()
        {
            httpclient.BaseAddress = new Uri("https://localhost:7025/Market/");

            httpclient.DefaultRequestHeaders.Accept.Clear();

            httpclient.DefaultRequestHeaders.Accept.Add
                (new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));

            InitializeComponent();
        }

        private async void datagrid_button_Click(object sender, RoutedEventArgs e)
        {
            var serverResponse = await httpclient.GetStringAsync("GetAllProducts");

            Response responseJSON = JsonConvert.DeserializeObject<Response>(serverResponse);

            market_datagrid.ItemsSource = responseJSON.products;
            DataContext = this;
        }

        private async void insert_button_Click(object sender, RoutedEventArgs e)
        {
            Market product = new Market();

            product.product_name = product_name_box.Text;
            product.product_id = int.Parse(product_id_box.Text);
            product.amount = int.Parse(amount_box.Text);
            product.price = Math.Round(double.Parse(price_box.Text),2);

            var serverResponse = await httpclient.PostAsJsonAsync("AddProduct", product);

            MessageBox.Show(serverResponse.ToString());
        }

        private async void select_button_Click(object sender, RoutedEventArgs e)
        {
            int id = int.Parse(product_id_box.Text);

            var serverResponse = await httpclient.GetStringAsync("GetProductByID/" + id);

            Response response = JsonConvert.DeserializeObject<Response>(serverResponse);

            Market product = new Market();
            product = response.product;

            product_name_box.Text = product.product_name;
            amount_box.Text = product.amount.ToString();
            price_box.Text = product.price.ToString();
        }

        private async void update_button_Click(object sender, RoutedEventArgs e)
        {
            int id = int.Parse(product_id_box.Text);

            Market product = new Market();
            product.product_name = product_name_box.Text;
            product.product_id = id;
            product.amount = int.Parse(amount_box.Text);
            product.price = double.Parse(price_box.Text);

            var serverResponse = await httpclient.PutAsJsonAsync("UpdateProduct/" + id, product);

            MessageBox.Show(serverResponse.ToString());
        }

        private async void delete_button_Click(object sender, RoutedEventArgs e)
        {
            int id = int.Parse(product_id_box.Text);

            var serverResponse = await httpclient.DeleteAsync("DeleteProduct/" + id);

            MessageBox.Show(serverResponse.ToString());
        }

        private void return_button_Click(object sender, RoutedEventArgs e)
        {
            MainWindow window1 = new MainWindow();
            window1.Show();
            this.Close();
        }
    }
}
