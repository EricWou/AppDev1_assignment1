using Assignment3_part2.Models;

namespace OrganismsPopulationTest
{
    public class Tests
    {
        OrganismsPopulation dailyPopulation { get; set; } = null;


        [SetUp]
        public void Setup()
        {
            dailyPopulation = new OrganismsPopulation(100,10,5);
        }

        [Test]
        public void PopulationSizePerDayTest()
        {
            int expected_PopulationSize = 160, actual_PopulationSize;

            actual_PopulationSize = dailyPopulation.PopulationSizePerDay(4);


            Assert.AreEqual(expected_PopulationSize, actual_PopulationSize);

            Assert.That(actual_PopulationSize, Is.TypeOf<int>());

            Assert.Pass();
        }
    }
}